import os # importando para usar função de limpar o terminal
import time

while True: # Estrutura de condição while repetindo enquanto as opções forem verdadeiras ou houver um break
    
    os.system("cls") # Função para limpar o terminal
    # Menu principal 
    print("==== Menu Principal ==== ")
    print("1. Estudante")
    print("2. Disciplina")
    print("3. Professor")
    print("4. Turma")
    print("5. Matricula")
    print("0. Sair do Sistema")
    # Coleta da opção 1 escolida pelo usuário
    opcao = int(input("Informe uma opção válida: "))
    print("===============================")

    # Verificação da opcao informada pelo usuário
    if opcao == 1 or opcao == 2 or opcao == 3 or opcao == 4 or opcao == 5:
        while True: # Estrutura de condição while caso as opções sejam verdadeiras
            os.system("cls") # Função para limpar o terminal
            print("Escolheu a opção {}".format(opcao))
            # Possibilidades de opcao selecionada pelo usuário
            if opcao == 1:
                print("Opção Estudante")
            elif opcao == 2:
                print("Opção Disciplina")
            elif opcao == 3:
                print("Opção Professor")
            elif opcao == 4:
                print("Opção Turma")
            elif opcao == 5:
                print("Opção Matrícula")

            print("== Menu secundário ==") 
            print("1. Incluir")
            print("2. Listar")
            print("3. Alterar")
            print("4. Excluir")
            print("5. Voltar ao menu anterior")
            # Coleta da opção secundaria do usuario
            opcao_2 = int(input("Informe uma opção válida: "))
            os.system("cls")
            print("Escolheu a opção {}".format(opcao_2))
            
            # Verificação da opcao informada pelo usuário
            if opcao_2 == 1 or opcao_2 == 2 or opcao_2 == 3 or opcao_2 == 4:
                # Possibilidades de opcao selecionada pelo usuário
                if opcao_2 == 1:
                    print("Opcao do menu secundario selecionado: Incluir") 
                elif opcao_2 == 2:
                    print("Opcao do menu secundario selecionado: Listar")
                elif opcao_2 == 3:
                    print("Opcao do menu secundario selecionado: Alterar")
                elif opcao_2 == 4:
                    print("Opcao do menu secundario selecionado: Excluir")
            # Condição selecionada pelo usuário para parar o loop do menu secundario e retornar ao menu principal
            elif opcao_2 == 5:
                print("Voltando ao menu principal")
                print("Limpando o terminal em 5 seg")
                time.sleep(5) # Pausa de 5 seg para execução do código
                break
    
            else: 
                print("Solicitou uma opção INVÁLIDA")    
                print("===============================")
            
            print("Limpando o terminal em 5 seg")
            time.sleep(5) # Pausa de 5 seg para execução do código
            
    # Verificação da opção "sair do sistema" para encerrar o programa
    elif opcao == 0:
        print("Opção selecionada: Sair do sistema")
        time.sleep(3) # Pausa de 3 seg para execução do código        
        break # Sinalização para sair do loop
    # Informar opção Inválida ao usuário
    else:
        print("Opção INVÁLIDA")
        print("Tente novamente")
        time.sleep(3) # Pausa de 3 seg para execução do código
        